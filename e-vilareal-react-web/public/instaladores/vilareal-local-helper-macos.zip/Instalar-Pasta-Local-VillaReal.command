#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  osascript -e 'display dialog "Instale Node.js (nodejs.org) e execute este instalador novamente." buttons {"OK"} default button 1 with title "Villa Real — Pasta local"' 2>/dev/null || true
  echo "Node.js não encontrado. Instale em https://nodejs.org"
  read -r -p "Pressione Enter para fechar..."
  exit 1
fi
node scripts/install-launchagent.mjs
echo ""
read -r -p "Pressione Enter para fechar..."
