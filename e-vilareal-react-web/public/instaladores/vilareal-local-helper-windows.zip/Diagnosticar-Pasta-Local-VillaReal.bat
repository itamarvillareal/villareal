@echo off
chcp 65001 >nul
title Villa Real - Diagnostico Pasta local
echo.
echo === Diagnostico Villa Real (Windows) ===
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Node.js nao instalado. Baixe em https://nodejs.org
) else (
  for /f "delims=" %%i in ('where node') do echo Node: %%i
  node --version
)
echo.
echo Porta 9876:
netstat -ano | findstr ":9876" | findstr "LISTENING" || echo   (nenhum processo escutando)
echo.
set "HELPER=%LOCALAPPDATA%\VillaReal\local-helper"
if exist "%HELPER%\Iniciar-Agente-VillaReal.bat" (
  echo Agente encontrado em %HELPER%
  echo Iniciando agente...
  call "%HELPER%\Iniciar-Agente-VillaReal.bat"
  timeout /t 3 /nobreak >nul
) else (
  echo [AVISO] Agente nao instalado. Execute Instalar-Pasta-Local-VillaReal.bat primeiro.
)
echo.
echo Teste http://127.0.0.1:9876/health no navegador.
echo.
if exist "%USERPROFILE%\.vilareal\local-helper.log" (
  echo --- Log ---
  powershell -NoProfile -Command "Get-Content -Path $env:USERPROFILE\.vilareal\local-helper.log -Tail 20"
) else (
  echo Log ainda nao existe: %%USERPROFILE%%\.vilareal\local-helper.log
)
echo.
pause
