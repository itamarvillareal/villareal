@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Villa Real - Pasta local
echo.
echo === Instalador Villa Real (Windows) ===
echo.
for /f "delims=" %%i in ('where node 2^>nul') do (
  set "NODE_EXE=%%i"
  goto :node_ok
)
echo [ERRO] Node.js nao encontrado.
echo Instale a versao LTS em https://nodejs.org
echo Depois feche esta janela e execute este instalador novamente.
echo.
pause
exit /b 1
:node_ok
echo Node.js: %NODE_EXE%
echo.
"%NODE_EXE%" scripts\install-windows.mjs
set ERR=%ERRORLEVEL%
echo.
if not "%ERR%"=="0" (
  echo Instalacao falhou. Veja o log em %%USERPROFILE%%\.vilareal\local-helper.log
  pause
  exit /b %ERR%
)
echo Instalacao concluida. Teste http://127.0.0.1:9876/health no navegador.
pause
