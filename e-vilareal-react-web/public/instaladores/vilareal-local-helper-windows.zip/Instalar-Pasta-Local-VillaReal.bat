@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Instale Node.js em https://nodejs.org e execute este instalador novamente.
  pause
  exit /b 1
)
node scripts\install-windows.mjs
echo.
pause
